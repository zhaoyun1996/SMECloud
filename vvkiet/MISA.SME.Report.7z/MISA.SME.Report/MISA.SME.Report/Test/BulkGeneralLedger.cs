﻿using MISA.SME.Report.RabbitMQ;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MISA.SME.Report.Test
{
    public class BulkGeneralLedger
    {
        public void BulkGeneral(GeneralLedger generalLedger, int i, NpgsqlConnection connection)
        {
            
        }
    }
}
