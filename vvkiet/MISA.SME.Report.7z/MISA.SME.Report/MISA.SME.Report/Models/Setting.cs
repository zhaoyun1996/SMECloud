﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MISA.SME.Report.Models
{
    public static class Setting
    {
        public static string ConnectionString { get; set; }
    }
}
